---
layout: post
date: 2019-06
inline: true
---
Our paper on deblurring for spiral real-time MRI using CNN accepted in Magentic Resonance in Medicine. 
