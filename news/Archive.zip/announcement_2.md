---
layout: post
date: 2020-01-31 
inline: true
---
Two papers accepted for oral presentations at the 28th annual meeting of the ISMRM 2020!
