---
layout: post
date: 2020-02 
inline: true
---
A short paper will be presented in Medical Imaging with Deep Learning (MIDL, 2020). 
